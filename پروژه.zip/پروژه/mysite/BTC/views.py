from django.shortcuts import render, redirect
from .forms import EmailForm
from .models import Email
from django.core.mail import send_mail
from django.conf import settings

def email_subscribe(request):
    if request.method == 'POST':
        form = EmailForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            news = Email.objects.create(email=email)
            news.save()
            send_congratulatory_email(email)
            
    else:
        form = EmailForm()
    return render(request, 'index.html', {'form': form})

def send_congratulatory_email(email):
    subject = 'Congratulations!'
    message = 'Congratulations on subscribing to our newsletter.'
    from_email = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, from_email, recipient_list, fail_silently=False)